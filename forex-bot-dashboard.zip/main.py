from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
import json
from pathlib import Path

app = FastAPI()
app.mount("/static", StaticFiles(directory="static"), name="static")

@app.get("/", response_class=HTMLResponse)
async def dashboard(request: Request):
    status_path = Path("bot_status.json")
    if status_path.exists():
        with open(status_path, "r") as file:
            data = json.load(file)
    else:
        data = {"trend": "Brak danych", "price": "Brak", "fvg": "Brak", "time": "Brak"}
    with open("templates/index.html", "r") as f:
        html = f.read()
    for key, value in data.items():
        html = html.replace(f"{{{{ {key} }}}}", str(value))
    return HTMLResponse(content=html)
